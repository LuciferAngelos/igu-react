// declaration.d.ts
declare module '*.scss';
declare module '*.png';
declare module '*.jpg';