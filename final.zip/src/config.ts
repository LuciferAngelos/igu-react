export const timerTimeLeft = 16028; //time in seconds
export const slotsLinks = [
	'https://www.igucasino.com/game/elvis-frog-in-vegas',
	'https://www.igucasino.com/game/gates-of-olympus',
	'https://www.igucasino.com/game/big-bass-bonanza',
	'https://www.igucasino.com/game/wolf-gold',
	'https://www.igucasino.com/game/wild-spin',
	'https://www.igucasino.com/game/sun-of-egypt-3',
	'https://www.igucasino.com/game/hell-hot-100',
	'https://www.igucasino.com/game/sugar-rush',
]
export const baseUrl = 'https://www.igucasino.com/?sign-up=modal';
export const langs = [
	'en',
	'de',
	'enAu',
	'enCa',
	'es',
	'frCa',
	'no',
	'ptBr',
	'sk'
]